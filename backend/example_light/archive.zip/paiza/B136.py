N,H,W = map(int,input().split()) 
sy,sx = map(int,input().split())
movement =  list(input()) # 文字列を強制で区切って格納
choco_in_location = [list(map(int, input().split())) for _ in range(H)]

now_location_x = sx - 1
now_location_y = sy - 1

for i in range(N):
    # 方向による位置更新
    if(movement[i]) == "F":
        now_location_y -= 1
    elif (movement[i]) == "B":
        now_location_y += 1
    elif (movement[i]) == "L":
        now_location_x -= 1
    elif (movement[i]) == "R":
        now_location_x += 1
    # チョコの位置と探索
    # print(now_location_x,now_location_y)
    print(choco_in_location[now_location_y][now_location_x])
